# ===============================================================
# GBIF BIODIVERSITY DASHBOARD — FINAL VERSION (92,142 POINTS)
# NO SAMPLING • FOLIUM CLUSTER • YEAR FILTER • SPECIES SEARCH
# ===============================================================

import streamlit as st
import pandas as pd
import folium
from folium.plugins import HeatMap, MarkerCluster
from streamlit_folium import st_folium
import plotly.express as px

# ---------------------------------------------------------------
# PAGE CONFIG
# ---------------------------------------------------------------
st.set_page_config(page_title="GBIF Dashboard", layout="wide")

# ---------------- BACKGROUND COLOR THEME -----------------------
st.markdown("""
    <style>
        .main {
            background-color: #f4f6fa;
        }
        .sidebar .sidebar-content {
            background-color: #eef1f6;
        }
    </style>
""", unsafe_allow_html=True)

st.title("🌍 GBIF Biodiversity Dashboard")


# ---------------------------------------------------------------
# LOAD DATA
# ---------------------------------------------------------------
@st.cache_data
def load_data():
    df = pd.read_csv("gbif_cleaned.csv")

    df["eventDate"] = pd.to_datetime(df["eventDate"], errors="coerce")
    df["year"] = df["eventDate"].dt.year
    df["month"] = df["eventDate"].dt.month

    return df

df = load_data()

# Metadata lists
countries = sorted(df["countryCode"].dropna().unique())
kingdoms = sorted(df["kingdom"].dropna().unique())
years = sorted(df["year"].dropna().unique())
species_list = sorted(df["species"].dropna().unique())

taxonomy_levels = {
    "Kingdom": "kingdom",
    "Phylum": "phylum",
    "Class": "class",
    "Order": "order",
    "Family": "family",
    "Genus": "genus",
    "Species": "species"
}


# ---------------------------------------------------------------
# SIDEBAR FILTERS
# ---------------------------------------------------------------
st.sidebar.title("🔍 Filters")

selected_country = st.sidebar.selectbox("Country", ["All"] + countries)
selected_kingdoms = st.sidebar.multiselect("Kingdom", kingdoms, default=kingdoms)
selected_years = st.sidebar.multiselect("Year", years, default=years)

species_query = st.sidebar.text_input("🔎 Search Species (Exact Match):")

use_heatmap = st.sidebar.checkbox("Heatmap", value=False)
use_clusters = st.sidebar.checkbox("Clusters", value=True)


# ---------------------------------------------------------------
# APPLY FILTERS
# ---------------------------------------------------------------
mask = pd.Series(True, index=df.index)

if selected_country != "All":
    mask &= df["countryCode"] == selected_country

mask &= df["kingdom"].isin(selected_kingdoms)
mask &= df["year"].isin(selected_years)

if species_query:
    mask &= df["species"].fillna("").str.lower() == species_query.lower()

filtered_df = df[mask]


# ---------------------------------------------------------------
# MAP + SUMMARY
# ---------------------------------------------------------------
st.subheader("🌍 Map & Summary")

map_col, summary_col = st.columns([2, 1])

with map_col:

    st.write("### Filtered Biodiversity Map")

    # -----------------------------------------------------------
    # AUTO-ZOOM LOGIC
    # -----------------------------------------------------------
    sub = filtered_df.dropna(subset=["decimalLatitude", "decimalLongitude"])

    if len(sub) > 0:
        center_lat = sub["decimalLatitude"].mean()
        center_lon = sub["decimalLongitude"].mean()
        zoom_level = 5 if selected_country != "All" else 3
    else:
        center_lat, center_lon, zoom_level = 20, 0, 2

    if species_query:
        zoom_level = 6

    # -----------------------------------------------------------
    # CREATE FOLIUM MAP
    # -----------------------------------------------------------
    m = folium.Map(location=[center_lat, center_lon], zoom_start=zoom_level)

    # Cluster for all records (NO SAMPLING)
    cluster = MarkerCluster().add_to(m)

    map_df = sub   # ALL 92k points

    heat_data = []

    # ---------------- ADD ALL POINTS ---------------------------
    for _, row in map_df.iterrows():
        lat, lon = row["decimalLatitude"], row["decimalLongitude"]
        heat_data.append([lat, lon])

        popup_text = f"""
        <b>Species:</b> {row['species']}<br>
        <b>Country:</b> {row['countryCode']}<br>
        <b>Date:</b> {row['eventDate']}
        """

        folium.CircleMarker(
            location=[lat, lon],
            radius=3,
            color="blue",
            fill=True,
            fill_opacity=0.7,
            popup=popup_text
        ).add_to(cluster if use_clusters else m)

    # ---------------- HEATMAP OPTION ---------------------------
    if use_heatmap:
        HeatMap(heat_data).add_to(m)

    # ---------------- DISPLAY MAP ------------------------------
    st_folium(
        m,
        width=850,
        height=500,
        key=f"map_{selected_country}_{species_query}_{selected_years}_{use_heatmap}"
    )


# ---------------------------------------------------------------
# SUMMARY STATISTICS
# ---------------------------------------------------------------
with summary_col:
    st.write("### 📊 Summary Statistics")
    st.metric("Total Records", len(filtered_df))
    st.metric("Unique Species", filtered_df["species"].nunique())
    st.metric("Unique Genera", filtered_df["genus"].nunique())
    st.metric("Unique Families", filtered_df["family"].nunique())


# ---------------------------------------------------------------
# TABS
# ---------------------------------------------------------------
tab1, tab2 = st.tabs(["📈 Time Series", "🧬 Taxonomy"])


# ---------------------------------------------------------------
# TAB 1 — TIME SERIES
# ---------------------------------------------------------------
with tab1:

    st.write("### Yearly Observations")

    yearly = filtered_df.groupby("year").size().reset_index(name="count")
    fig_year = px.line(yearly, x="year", y="count", markers=True,
                       title="Yearly Observation Trend", template="plotly_white")
    fig_year.update_layout(height=350)
    st.plotly_chart(fig_year, use_container_width=True)

    st.write("### Monthly Observations")

    monthly = filtered_df.groupby("month").size().reset_index(name="count")
    fig_month = px.bar(monthly, x="month", y="count",
                       title="Monthly Observation Distribution", template="plotly_white")
    fig_month.update_layout(height=350)
    st.plotly_chart(fig_month, use_container_width=True)


# ---------------------------------------------------------------
# TAB 2 — TAXONOMY
# ---------------------------------------------------------------
with tab2:

    st.write("### Select Taxonomic Level")

    level_name = st.selectbox("Choose Level", list(taxonomy_levels.keys()))
    col_name = taxonomy_levels[level_name]

    values = filtered_df[col_name].fillna("Unknown")

    top10 = values.value_counts().reset_index()
    top10.columns = [level_name, "Count"]
    top10 = top10.head(10)

    fig_tax = px.bar(top10, x=level_name, y="Count",
                     title=f"Top 10 {level_name} Observed", template="plotly_white")
    fig_tax.update_layout(height=400, xaxis_tickangle=-40)
    st.plotly_chart(fig_tax, use_container_width=True)


# ---------------------------------------------------------------
# DOWNLOAD FILTERED DATA
# ---------------------------------------------------------------
st.subheader("📥 Download Filtered Dataset")

st.download_button(
    label="Download CSV",
    data=filtered_df.to_csv(index=False),
    file_name="filtered_gbif.csv",
    mime="text/csv",
    use_container_width=True,
    key="download_filtered"
)
